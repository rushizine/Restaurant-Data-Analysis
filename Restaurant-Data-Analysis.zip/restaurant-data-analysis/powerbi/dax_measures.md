# Power BI - Simple Guide (Data Model, DAX, Dashboard)

## 1. Load the data
Open Power BI Desktop -> **Get Data -> Text/CSV** -> choose `data/restaurants_clean.csv`.
One table is enough: `restaurants_clean` (9,551 rows). No joins needed.

Set these in the **Column tools** tab:
- `longitude` -> Data category: **Longitude**
- `latitude` -> Data category: **Latitude**
- `city` -> **City**

## 2. Calculated columns (Modeling -> New column)

```DAX
Rating Status = IF ( restaurants_clean[aggregate_rating] > 0, "Rated", "Not rated" )
```

```DAX
Price Label =
SWITCH (
    restaurants_clean[price_range],
    1, "1 - Low",
    2, "2 - Medium",
    3, "3 - High",
    4, "4 - Premium"
)
```

## 3. Measures (Modeling -> New measure)

```DAX
Total Restaurants = COUNTROWS ( restaurants_clean )
```

```DAX
Avg Rating =
CALCULATE ( AVERAGE ( restaurants_clean[aggregate_rating] ), restaurants_clean[aggregate_rating] > 0 )
```

```DAX
Total Votes = SUM ( restaurants_clean[votes] )
```

```DAX
Online Delivery Restaurants =
CALCULATE ( [Total Restaurants], restaurants_clean[has_online_delivery] = "Yes" )
```

```DAX
% Online Delivery = DIVIDE ( [Online Delivery Restaurants], [Total Restaurants] )
```

```DAX
Table Booking Restaurants =
CALCULATE ( [Total Restaurants], restaurants_clean[has_table_booking] = "Yes" )
```

```DAX
% Table Booking = DIVIDE ( [Table Booking Restaurants], [Total Restaurants] )
```

**What they do (in simple words):**
- `COUNTROWS` counts the rows (restaurants).
- `CALCULATE` changes the filter. In `Avg Rating` we only use rated restaurants.
- `DIVIDE` does a division and avoids "divide by zero" errors.

## 4. Dashboard (2 pages)

**Page 1 - Overview**
- 5 KPI cards: Total Restaurants, Avg Rating, Total Votes, % Online Delivery, % Table Booking
- Bar chart: Top 10 cities by Total Restaurants
- Column chart: Price Label by Total Restaurants
- Donut chart: Rating text
- Slicers: City, Price range, Has Online Delivery, Has Table Booking

**Page 2 - Details**
- Column chart: Price Label vs % Online Delivery and % Table Booking
- Scatter chart: votes (X) and aggregate_rating (Y)
- Table: Top 10 restaurants by votes (restaurant_name, city, aggregate_rating, votes)
- Map: longitude and latitude, size = Total Restaurants

## 5. Tips
- Use the same colours on both pages.
- Take screenshots of both pages, save them in `images/` (for example `powerbi_page1.png`) and add them to the README.
- Save your file as `powerbi/restaurant_dashboard.pbix`.
